

	
PowerShell.exe Start-Process "chrome.exe --load-extension=C:\Users\%USERNAME%\chrome\extension"

	